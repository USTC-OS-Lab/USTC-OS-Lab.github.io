    #ifndef BACKUP_H
    #define BACKUP_H

    #include <string>

    void FullBackup(const std::string &srcDir, const std::string &backupDir);
    void DiffBackup(const std::string &srcDir,const std::string &backupDir);

    #endif // BACKUP_H
