#include "backup.h"
#include "restore.h"
#include <iostream>
#include <map>
#include <vector>
#include <string>

void PrintUsage() {
    std::cout << "Usage:\n";
    std::cout << "  backup_tool backup --srcDir=<source_directory> --backupDir=<backup_directory>\n";
    std::cout << "  backup_tool diff_backup --srcDir=<previous_directory> --backupDir=<backup_directory>\n";
    std::cout << "  backup_tool restore --backupDir=<backup_directory> --restoreDir=<restore_directory>\n";
}

std::map<std::string, std::string> ParseArguments(int argc, char *argv[]) {
    std::map<std::string, std::string> args;
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg.substr(0, 2) == "--") {
            auto pos = arg.find('=');
            if (pos != std::string::npos) {
                std::string key = arg.substr(0, pos);
                std::string value = arg.substr(pos + 1);
                args[key] = value;
            } else if (i + 1 < argc) {
                args[arg] = argv[++i];
            }
        }
    }
    return args;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        PrintUsage();
        return 1;
    }

    std::string command = argv[1];
    auto args = ParseArguments(argc, argv);

    if (command == "backup") {
        if (args.find("--srcDir") != args.end() && args.find("--backupDir") != args.end()) {
            std::string srcDir = args["--srcDir"];
            std::string backupDir = args["--backupDir"];
            FullBackup(srcDir, backupDir);
        } else {
            PrintUsage();
            return 1;
        }
    } else if (command == "diff_backup") {
        if (args.find("--srcDir") != args.end()  && args.find("--backupDir") != args.end()) {
            std::string srcDir = args["--srcDir"];
            std::string backupDir = args["--backupDir"];
            DiffBackup(srcDir, backupDir);
        } else {
            PrintUsage();
            return 1;
        }
    } else if (command == "restore") {
        if (args.find("--backupDir") != args.end() && args.find("--restoreDir") != args.end()) {
            std::string backupDir = args["--backupDir"];
            std::string restoreDir = args["--restoreDir"];
            RestoreBackup(backupDir, restoreDir);
        } else {
            PrintUsage();
            return 1;
        }
    } else {
        PrintUsage();
        return 1;
    }

    return 0;
}
