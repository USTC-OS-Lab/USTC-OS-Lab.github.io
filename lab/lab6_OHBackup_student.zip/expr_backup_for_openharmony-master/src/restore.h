// restore.h
#ifndef RESTORE_H
#define RESTORE_H

#include <string>

void RestoreBackup(const std::string &backupDir, const std::string &restoreDir);

#endif // RESTORE_H