# expr_backup_for_openharmony

#### 介绍
该代码是OpenHarmony实验中高性能目录差异分析的源码。由闫超美创建，陈巩固做了微调和修改。


