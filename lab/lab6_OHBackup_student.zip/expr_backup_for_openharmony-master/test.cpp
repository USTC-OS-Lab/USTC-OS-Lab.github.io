#include<cstdio>
#include<openssl/sha.h>

int main(){
    SHA256_CTX sha256;  
    SHA256_Init(&sha256);
    return 0;
}