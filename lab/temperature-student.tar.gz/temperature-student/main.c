#include "lvgl/lvgl.h"
#include "lvgl/demos/lv_demos.h"
#include "lv_drivers/display/fbdev.h"
#include "tmp.h"

#include <unistd.h>
#include <pthread.h>
#include <time.h>
#include <sys/time.h>
#include <signal.h>
#include <unistd.h>
#define DISP_BUF_SIZE (128 * 1024)

void lv_chart(void)//界面设计函数
{
    LV_FONT_DECLARE(lv_font_simsun_48_cjk);
    lv_obj_t * chart1;
    chart1 = lv_chart_create(lv_scr_act());//创建图表
    lv_obj_set_size(chart1, 620, 600);//设置图表大小为x = 620,y = 600(开发板的分辨率为720*1280)这里占用一半
    //TODO: 设置图表形式为折线图
    lv_chart_set_type(chart1,______);
    //TODO: 设置折线图显示点的数量
    lv_chart_set_point_count(chart1, ______);
    lv_chart_set_axis_tick(chart1, LV_CHART_AXIS_PRIMARY_Y, 10, 5, 6, 2, true, 50);//设定图表只显示y轴并且设置刻度线具体数值要求，这里不具体讲述，详情直接见附录网站和效果图
    //TODO: 设置y轴坐标范围,可以设置为-10~50
    lv_chart_set_range(chart1,______, ____, ____);

    lv_obj_set_pos(chart1, 50, 340);
    lv_chart_series_t * ser1 = lv_chart_add_series(chart1, lv_palette_main(LV_PALETTE_RED), LV_CHART_AXIS_PRIMARY_Y);//设置点的颜色等细节
    lv_chart_refresh(chart1);//释放空间（更新）

    //标签Label//
    lv_obj_t * cz_label1 = lv_label_create(lv_scr_act());//创建标签命名为label1
    lv_obj_set_style_text_font(cz_label1, &lv_font_simsun_48_cjk, 0);//设定标签使用文本字体
    lv_obj_set_width(cz_label1, 360);//设置标签宽度
    lv_obj_set_pos(cz_label1, 200, 150);//设置标签位置

    lv_obj_t * cz_label2 = lv_label_create(lv_scr_act());//同上
    lv_obj_set_style_text_font(cz_label2, &lv_font_simsun_48_cjk, 0);
    lv_obj_set_width(cz_label2, 400);
    lv_obj_set_pos(cz_label2, 200, 50);//设置标签位置
    //TODO: 自定义文本内容，学号
    lv_label_set_text(cz_label2, ______);//设置文本内容

    float i = 0;//设置浮点数i用作读取温度参数值
    
    while(1) {
    	i = tmp();//读取温度数值
        lv_chart_set_next_value(chart1, ser1, (int)i);//将数值显示在折线图上
        lv_label_set_text_fmt(cz_label1,"温度：%.1f ℃",i);//汉字显示当前数值

        lv_task_handler();//缓存
        
        usleep(1000000);//一秒暂停，usleep的暂停单位时间为1ns，这里为1000000为1s
    }
}

// 清理函数，用于在程序退出时刷新屏幕并清除图像
void cleanup() {
    // 清除屏幕
    lv_obj_clean(lv_scr_act());

    // 刷新显示
    lv_task_handler();
    usleep(100000);  // 等待一段时间以确保刷新完成

    // 关闭显示驱动
    fbdev_exit();

    // 退出 LVGL
    lv_deinit();

    printf("Screen cleared and program exited.\n");
    exit(0);
}

// 信号处理函数，捕获 SIGINT 信号
void signal_handler(int signal) {
    if (signal == SIGINT) {
        cleanup();
    }
}

// /*Set in lv_conf.h as `LV_TICK_CUSTOM_SYS_TIME_EXPR`*/
uint32_t custom_tick_get(void)
{
    static uint64_t start_ms = 0;
    if(start_ms == 0) {
        struct timeval tv_start;
        gettimeofday(&tv_start, NULL);
        start_ms = (tv_start.tv_sec * 1000000 + tv_start.tv_usec) / 1000;
    }

    struct timeval tv_now;
    gettimeofday(&tv_now, NULL);
    uint64_t now_ms;
    now_ms = (tv_now.tv_sec * 1000000 + tv_now.tv_usec) / 1000;

    uint32_t time_ms = now_ms - start_ms;
    return time_ms;
}

int main(void)
{
    /*LittlevGL init*/
    lv_init();
    /*Linux frame buffer device init*/

    fbdev_init();

    /*A small buffer for LittlevGL to draw the screen's content*/
    static lv_color_t buf[DISP_BUF_SIZE];

    /*Initialize a descriptor for the buffer*/
    static lv_disp_draw_buf_t disp_buf;
    lv_disp_draw_buf_init(&disp_buf, buf, NULL, DISP_BUF_SIZE);

    /*Initialize and register a display driver*/
    static lv_disp_drv_t disp_drv;
    lv_disp_drv_init(&disp_drv);
    disp_drv.draw_buf   = &disp_buf;
    disp_drv.flush_cb   = fbdev_flush;
    disp_drv.hor_res    = 720;
    disp_drv.ver_res    = 1280;
    lv_disp_drv_register(&disp_drv);
    signal(SIGINT, signal_handler);
    lv_chart();

    return 0;
}