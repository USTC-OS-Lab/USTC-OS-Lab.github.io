==============
NXP VGLite GPU
==============

API
---

:ref:`lv_draw_vglite`

:ref:`lv_draw_vglite_arc`

:ref:`lv_draw_vglite_blend`

:ref:`lv_draw_vglite_line`

:ref:`lv_draw_vglite_rect`

